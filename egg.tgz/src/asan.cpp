// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("asan\n", stdout);
  return lionss_run_workload("asan");
}
