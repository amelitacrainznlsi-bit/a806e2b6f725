// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("bazel build"); }
int main(){
  announce();
  return lionss_run_workload("bazel-build");
}
