// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("dependency review"); }
int main(){
  announce();
  return lionss_run_workload("dependency-review");
}
