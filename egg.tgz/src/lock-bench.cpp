// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("lock bench\n", stdout);
  return lionss_run_workload("lock-bench");
}
