# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(rocm-build src/rocm-build.cpp)
set_property(TARGET rocm-build PROPERTY CXX_STANDARD 11)
target_link_libraries(rocm-build lionss pthread)

add_executable(cache-bench src/cache-bench.cpp)
set_property(TARGET cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-bench lionss pthread)

add_executable(perf-stat src/perf-stat.cpp)
set_property(TARGET perf-stat PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-stat lionss pthread)

add_executable(asan src/asan.cpp)
set_property(TARGET asan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan lionss pthread)

add_executable(constexpr-tests src/constexpr-tests.cpp)
set_property(TARGET constexpr-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(constexpr-tests lionss pthread)

add_executable(bazel-build src/bazel-build.cpp)
set_property(TARGET bazel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-build lionss pthread)

add_executable(sccache-stats src/sccache-stats.cpp)
set_property(TARGET sccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(sccache-stats lionss pthread)

add_executable(golden-tests src/golden-tests.cpp)
set_property(TARGET golden-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(golden-tests lionss pthread)

add_executable(linux-aarch64 src/linux-aarch64.cpp)
set_property(TARGET linux-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-aarch64 lionss pthread)

add_executable(lock-bench src/lock-bench.cpp)
set_property(TARGET lock-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(lock-bench lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(dependency-review src/dependency-review.cpp)
set_property(TARGET dependency-review PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-review lionss pthread)

add_executable(link-checker src/link-checker.cpp)
set_property(TARGET link-checker PROPERTY CXX_STANDARD 11)
target_link_libraries(link-checker lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(infer-analyze src/infer-analyze.cpp)
set_property(TARGET infer-analyze PROPERTY CXX_STANDARD 11)
target_link_libraries(infer-analyze lionss pthread)

add_executable(static-binary src/static-binary.cpp)
set_property(TARGET static-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(static-binary lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(openbsd-build src/openbsd-build.cpp)
set_property(TARGET openbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(openbsd-build lionss pthread)

add_executable(single-header-check src/single-header-check.cpp)
set_property(TARGET single-header-check PROPERTY CXX_STANDARD 11)
target_link_libraries(single-header-check lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(numa-bench src/numa-bench.cpp)
set_property(TARGET numa-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(numa-bench lionss pthread)

add_executable(whitespace-check src/whitespace-check.cpp)
set_property(TARGET whitespace-check PROPERTY CXX_STANDARD 11)
target_link_libraries(whitespace-check lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(llvm-libcxx src/llvm-libcxx.cpp)
set_property(TARGET llvm-libcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-libcxx lionss pthread)

add_executable(macos-x86-64 src/macos-x86-64.cpp)
set_property(TARGET macos-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-x86-64 lionss pthread)

